export type ReceiptStatus = 'Review' | 'Pending' | 'Disetujui' | 'Ditolak';

export interface Receipt {
  id: string;
  karyawan: string;
  initials: string;
  avatarBg: string; // Tailwind class
  avatarColor: string; // Tailwind class
  merchant: string;
  ocrNominal: number;
  klaim: number;
  kategori: string;
  status: ReceiptStatus;
  tanggal: string;
  departemen: string;
}

export interface StrukApproval {
  id: string;
  karyawan: string;
  merchant: string;
  nominal: number;
  keputusan: 'Disetujui' | 'Ditolak';
  diprosesOleh: string;
  waktu: string;
  catatan: string;
}

export type InvoiceStatus = 'Due' | 'Pending' | 'Dibayar' | 'Ditolak';
export type InvoiceSource = 'Scan' | 'Manual';

export interface InvoiceItem {
  id: string;
  deskripsi: string;
  qty: number;
  harga: number;
  subtotal: number;
}

export interface Invoice {
  id: string; // e.g., INV-0042
  vendor: string;
  total: number;
  jatuhTempo: string;
  kategori: string;
  sumber: InvoiceSource;
  status: InvoiceStatus;
  catatan?: string;
  npwp?: string;
  tanggalInv?: string;
  ppn?: number;
  keterangan?: string;
  items?: InvoiceItem[];
  sha256Hash?: string;
  uploadOleh?: string;
  waktuUpload?: string;
}

export interface AuditLog {
  id: string;
  iconBg: string; // e.g., bg-green-500
  title: string;
  details: string;
  waktu: string;
}

export interface NotificationItem {
  id: string;
  type: 'due' | 'flag' | 'new' | 'success';
  title: string;
  subtitle: string;
  time: string;
  read: boolean;
}

export interface AppSettings {
  varianceLimit: number; // in %
  maxClaimLimit: number; // in IDR
  thresholdSingle: string;
  thresholdTwo: string;
  thresholdThree: string;
}
