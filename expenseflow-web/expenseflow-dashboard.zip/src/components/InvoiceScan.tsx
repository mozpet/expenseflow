import React, { useState } from 'react';
import { Invoice } from '../types';
import { 
  Scan, 
  Sparkles, 
  FileText, 
  Lock, 
  Check, 
  ShieldCheck, 
  AlertTriangle, 
  Loader2, 
  UploadCloud,
  Clock,
  User
} from 'lucide-react';

interface InvoiceScanProps {
  onAddInvoice: (invoice: Invoice) => void;
}

export const InvoiceScan: React.FC<InvoiceScanProps> = ({ onAddInvoice }) => {
  const [loading, setLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState('');
  const [hasScanned, setHasScanned] = useState(true); // Default to prompt's scannner state
  const [kategori, setKategori] = useState('Software & lisensi');
  const [catatanVerifikasi, setCatatanVerifikasi] = useState('Invoice sesuai PO-2026-0018');

  // Hardcoded locked OCR Results from Prompt
  const ocrResults = {
    id: 'INV-2026-0042',
    vendor: 'PT Maju Jaya Indonesia',
    tanggalInv: '20 Mei 2026',
    jatuhTempo: '26 Mei 2026',
    subtotal: 16666667,
    ppn: 1833333,
    total: 18500000,
    hash: 'b7d3e1f2a9c8e185a1a1f021c3b4a5d6e7f8e9a0f012b3c4d5e6a1b2c3d4e5f6'
  };

  const handleSimulateScan = () => {
    setLoading(true);
    setHasScanned(false);
    
    // Animate OCR simulation steps
    const steps = [
      'Menghubungkan ke layanan OCR engine...',
      'Mengekstraksi layout baris koordinat...',
      'Membaca teks terenkripsi dokumen...',
      'Mencocokkan NPWP & Nama Entitas Vendor...',
      'Memverifikasi integritas total aritmatika...',
      'Selesai! Menyajikan ringkasan hasil...'
    ];

    steps.forEach((stepText, idx) => {
      setTimeout(() => {
        setLoadingStep(stepText);
        if (idx === steps.length - 1) {
          setLoading(false);
          setHasScanned(true);
        }
      }, (idx + 1) * 450);
    });
  };

  const handleSubmit = () => {
    if (!hasScanned) return;

    const newInvoice: Invoice = {
      id: ocrResults.id,
      vendor: ocrResults.vendor,
      total: ocrResults.total,
      jatuhTempo: ocrResults.jatuhTempo,
      kategori: kategori,
      sumber: 'Scan',
      status: 'Due', // Due as in default OCR tag
      catatan: catatanVerifikasi,
      npwp: '12.345.678.9-000.000',
      tanggalInv: ocrResults.tanggalInv,
      ppn: ocrResults.ppn,
      items: [
        { id: '1', deskripsi: 'Adobe CC Software All Apps Subscription', qty: 1, harga: ocrResults.subtotal, subtotal: ocrResults.subtotal }
      ],
      sha256Hash: ocrResults.hash,
      uploadOleh: 'Sari Rahma',
      waktuUpload: '26 Mei 2026, 09:41'
    };

    onAddInvoice(newInvoice);
    alert('Invoice hasil Scan OCR berhasil disimpan & dikirim untuk approval!');
  };

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0
    }).format(val);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Left Column Form */}
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
        <div className="flex justify-between items-center pb-3 border-b border-slate-100 dark:border-slate-800">
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
            <Scan className="w-4.5 h-4.5 text-indigo-600 animate-pulse" />
            Scan Invoice — OCR Otomatis
          </h3>
          <span className="text-[10px] bg-indigo-50 text-indigo-700 dark:bg-indigo-950/30 dark:text-indigo-400 font-mono font-bold px-2 py-0.5 rounded flex items-center gap-1">
            <Sparkles className="w-3 h-3" />
            AI Powered
          </span>
        </div>

        {/* Stepper progress */}
        <div className="flex gap-1">
          <div className="flex-1 text-center pb-2 border-b-2 border-emerald-500 font-bold text-[10px] text-emerald-600 flex items-center justify-center gap-1.5">
            <Check className="w-3.5 h-3.5" />
            <span>1. Upload File </span>
          </div>
          <div className={`flex-1 text-center pb-2 border-b-2 font-bold text-[10px] flex items-center justify-center gap-1.5 ${
            hasScanned ? 'border-indigo-500 text-indigo-600' : 'border-slate-100 text-slate-400'
          }`}>
            <span>2. Hasil OCR</span>
          </div>
          <div className={`flex-1 text-center pb-2 border-b-2 font-bold text-[10px] flex items-center justify-center gap-1.5 ${
            hasScanned ? 'border-slate-300 text-slate-500' : 'border-slate-100 text-slate-400'
          }`}>
            <span>3. Verifikasi</span>
          </div>
        </div>

        {/* Upload Zone */}
        {!loading && (
          <div 
            onClick={handleSimulateScan}
            className="border-2 border-dashed border-slate-200 dark:border-slate-800 bg-slate-50 hover:bg-slate-100 dark:bg-slate-950/20 dark:hover:bg-slate-950/40 rounded-xl p-5 text-center cursor-pointer transition flex flex-col items-center justify-center gap-2"
          >
            <UploadCloud className="w-8 h-8 text-indigo-600" />
            <div>
              <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">invoice_PT_MajuJaya_042.pdf</p>
              <span className="text-[11px] text-emerald-600 block font-semibold mt-0.5">Dokumen berhasil terunggah (234 KB)</span>
            </div>
            <p className="text-[10px] text-slate-400">Klik di sini untuk men-scan ulang berkas atau mengunggah berkas lain</p>
          </div>
        )}

        {/* Scan progress loader */}
        {loading && (
          <div className="py-12 border border-indigo-100 dark:border-indigo-950 rounded-xl bg-indigo-50/10 dark:bg-indigo-950/5 flex flex-col items-center justify-center gap-3">
            <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
            <p className="text-xs font-semibold text-indigo-800 dark:text-indigo-300">{loadingStep}</p>
            <span className="text-[10px] text-slate-400 font-mono">Running Azure Document Intelligence OCR Core v3.0</span>
          </div>
        )}

        {/* OCR Extracted Results Box */}
        {hasScanned && !loading && (
          <div className="space-y-4">
            <div className={`bg-indigo-50/50 border border-indigo-100 dark:bg-indigo-950/10 dark:border-indigo-900/40 rounded-xl p-4 text-xs text-indigo-900 dark:text-indigo-400 space-y-2`}>
              <div className="flex items-center gap-2 font-bold text-[11px] uppercase tracking-wide border-b border-indigo-100 dark:border-indigo-950/50 pb-2">
                <Check className="w-4 h-4 text-emerald-600" />
                <span>Hasil Ekstraksi OCR Sukses — Data Terkunci</span>
              </div>
              <div className="space-y-1.5 font-sans">
                <div className="flex justify-between py-1 border-b border-indigo-100/30 dark:border-indigo-950/10">
                  <span className="text-slate-500">No. Invoice</span>
                  <span className="font-bold font-mono text-slate-900 dark:text-slate-100">{ocrResults.id}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-indigo-100/30 dark:border-indigo-950/10">
                  <span className="text-slate-500">Nama Vendor</span>
                  <span className="font-semibold text-slate-900 dark:text-slate-100">{ocrResults.vendor}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-indigo-100/30 dark:border-indigo-950/10">
                  <span className="text-slate-500">Tanggal Faktur</span>
                  <span className="font-medium text-slate-900 dark:text-slate-100">{ocrResults.tanggalInv}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-indigo-100/30 dark:border-indigo-950/10">
                  <span className="text-slate-500">Jatuh Tempo</span>
                  <span className="font-semibold text-rose-600">{ocrResults.jatuhTempo}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-indigo-100/30 dark:border-indigo-950/10">
                  <span className="text-slate-500">Subtotal</span>
                  <span className="font-semibold font-mono text-slate-800 dark:text-slate-200">{formatCurrency(ocrResults.subtotal)}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-indigo-100/30 dark:border-indigo-950/10">
                  <span className="text-slate-500">PPN 11%</span>
                  <span className="font-semibold font-mono text-slate-800 dark:text-slate-200">{formatCurrency(ocrResults.ppn)}</span>
                </div>
                <div className="flex justify-between py-1.5 text-base font-bold text-slate-900 dark:text-white">
                  <span>Total Tagihan (Rp)</span>
                  <span className="text-indigo-700 dark:text-indigo-400 font-mono font-bold">{formatCurrency(ocrResults.total)}</span>
                </div>
              </div>
            </div>

            {/* Warning Message */}
            <div className="bg-amber-50/50 border border-amber-200 dark:bg-amber-950/20 dark:border-amber-900/50 rounded-xl p-3 text-[11px] text-amber-800 dark:text-amber-400 flex items-start gap-2 leading-relaxed">
              <Lock className="w-4 h-4 mt-0.5 text-amber-600 shrink-0" />
              <span>
                Data hasil OCR di atas terkunci secara otomatis oleh sistem keamanan & integritas akuntansi untuk mencegah penyelewengan. Tim finance hanya berwenang melengkapi kategori penempatan anggaran serta menulis catatan verifikasi pembanding.
              </span>
            </div>

            {/* Editable Fields for User */}
            <div className="space-y-4 pt-2">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block">Kategori Pembiayaan (Bisa diisi)</label>
                <select 
                  value={kategori}
                  onChange={(e) => setKategori(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50/50 dark:bg-slate-800/20 text-slate-800 dark:text-slate-100 focus:outline-none"
                >
                  <option>Software & lisensi</option>
                  <option>Percetakan</option>
                  <option>Logistik</option>
                  <option>Lainnya</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block">Catatan Verifikasi</label>
                <textarea 
                  rows={2}
                  value={catatanVerifikasi}
                  onChange={(e) => setCatatanVerifikasi(e.target.value)}
                  className="w-full text-xs p-3 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50/50 dark:bg-slate-800/20 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  placeholder="Contoh: No PO sesuai..."
                />
              </div>

              <button
                type="button"
                onClick={handleSubmit}
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md transition uppercase tracking-wider"
              >
                Kirim Untuk Approval
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Right Column Preview */}
      <div className="space-y-4">
        {/* Document Frame Mockup */}
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
          <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
            <FileText className="w-4 h-4 text-indigo-600" />
            Preview Dokumen Terlampir
          </h4>
          <div className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-xl flex flex-col items-center justify-center p-8 h-64 text-slate-400 select-none">
            <Scan className="w-12 h-12 text-slate-300 dark:text-slate-800 animate-pulse mb-2" />
            <p className="text-xs font-bold text-slate-700 dark:text-slate-300">invoice_PT_MajuJaya_042.pdf</p>
            <span className="text-[10px] text-slate-400 mt-0.5">Halaman 1 dari 2 · PDF Terlindungi sandi SHA256</span>
          </div>
        </div>

        {/* File Integrity block */}
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-3">
          <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
            <ShieldCheck className="w-4.5 h-4.5 text-emerald-600" />
            Integritas Dokumen Digital
          </h4>
          <div className="space-y-2 text-xs divide-y divide-slate-100 dark:divide-slate-800">
            <div className="flex justify-between py-1.5">
              <span className="text-slate-400">SHA-256 Hash</span>
              <span className="font-mono text-[9px] text-slate-500 font-semibold uppercase">{ocrResults.hash.substring(0, 24)}...</span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-slate-400">Waktu Upload</span>
              <span className="font-medium text-slate-800 dark:text-slate-200 flex items-center gap-1">
                <Clock className="w-3 h-3 text-slate-400" />
                26 Mei 2026, 09:41
              </span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-slate-400">Upload Oleh</span>
              <span className="font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1">
                <User className="w-3 h-3 text-slate-400" />
                Sari Rahma
              </span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-slate-400">Status Integritas Perkas</span>
              <span className="font-bold text-emerald-600 flex items-center gap-1.5 font-sans">
                <Check className="w-3.5 h-3.5" />
                Terkunci (ReadOnly)
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
