import React, { useState } from 'react';
import { 
  initialReceipts, 
  initialStrukApprovals, 
  initialInvoices, 
  initialHistoryInvoices, 
  initialAuditLogs, 
  initialNotifications, 
  defaultSettings 
} from './data';
import { 
  Receipt, 
  StrukApproval, 
  Invoice, 
  AuditLog, 
  NotificationItem, 
  AppSettings 
} from './types';
import { ReceiptInbox } from './components/ReceiptInbox';
import { ReceiptHistory } from './components/ReceiptHistory';
import { InvoiceInbox } from './components/InvoiceInbox';
import { InvoiceInput } from './components/InvoiceInput';
import { InvoiceScan } from './components/InvoiceScan';
import { InvoiceHistory as InvoiceHistoryView } from './components/InvoiceHistory';
import { Reports } from './components/Reports';
import { AuditLogView } from './components/AuditLogView';
import { NotificationsView } from './components/NotificationsView';
import { SettingsView } from './components/SettingsView';
import { KaryawanManagement } from './components/KaryawanManagement';
import { MasterVendor } from './components/MasterVendor';

import { 
  Inbox, 
  CheckCheck, 
  FileText, 
  FilePlus, 
  Scan, 
  History, 
  BarChart3, 
  ShieldCheck, 
  Bell, 
  Settings, 
  Menu, 
  X, 
  FileSpreadsheet,
  Download,
  Receipt as ReceiptIcon,
  Users,
  Building
} from 'lucide-react';

export default function App() {
  // Global React States
  const [activePage, setActivePage] = useState<string>('inbox');
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);

  const [receipts, setReceipts] = useState<Receipt[]>(initialReceipts);
  const [receiptHistory, setReceiptHistory] = useState<StrukApproval[]>(initialStrukApprovals);
  const [invoices, setInvoices] = useState<Invoice[]>(initialInvoices);
  const [invoiceHistory, setInvoiceHistory] = useState<Invoice[]>(initialHistoryInvoices);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(initialAuditLogs);
  const [notifications, setNotifications] = useState<NotificationItem[]>(initialNotifications);
  const [settings, setSettings] = useState<AppSettings>(defaultSettings);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0
    }).format(val);
  };

  // 1. Employee Receipt / Struk approval handlers
  const handleApproveReceipt = (id: string, note: string) => {
    const item = receipts.find(r => r.id === id);
    if (!item) return;

    // Append to receipt history
    const approvalRecord: StrukApproval = {
      id: `RA-${Date.now()}`,
      karyawan: item.karyawan,
      merchant: item.merchant,
      nominal: item.klaim,
      keputusan: 'Disetujui',
      diprosesOleh: 'Sari Rahma',
      waktu: 'Hari ini, ' + new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      catatan: note
    };

    setReceiptHistory([approvalRecord, ...receiptHistory]);
    setReceipts(receipts.filter(r => r.id !== id));

    // Append to audit logs
    const auditRecord: AuditLog = {
      id: `LOG-${Date.now()}`,
      iconBg: 'bg-emerald-600',
      title: `Struk ${item.karyawan} ($P{item.merchant}) — disetujui Finance Manager`,
      details: `Disetujui oleh Sari Rahma · Nominal ${formatCurrency(item.klaim)} · Catatan: ${note}`,
      waktu: new Date().toLocaleDateString('id-ID')
    };
    setAuditLogs([auditRecord, ...auditLogs]);

    // Add green notification success
    const notifRecord: NotificationItem = {
      id: `NT-${Date.now()}`,
      type: 'success',
      title: `Struk disetujui — ${item.karyawan}`,
      subtitle: `Klaim Rp ${new Intl.NumberFormat('id-ID').format(item.klaim)} untuk ${item.merchant} telah diverifikasi.`,
      time: 'Baru saja',
      read: false
    };
    setNotifications([notifRecord, ...notifications]);
  };

  const handleRejectReceipt = (id: string, note: string) => {
    const item = receipts.find(r => r.id === id);
    if (!item) return;

    // Append to receipt history as Rejected
    const approvalRecord: StrukApproval = {
      id: `RA-${Date.now()}`,
      karyawan: item.karyawan,
      merchant: item.merchant,
      nominal: item.klaim,
      keputusan: 'Ditolak',
      diprosesOleh: 'Sari Rahma',
      waktu: 'Hari ini, ' + new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      catatan: note || 'Dugaan manipulasi / ketidaksesuaian fisik struk dengan klaim'
    };

    setReceiptHistory([approvalRecord, ...receiptHistory]);
    setReceipts(receipts.filter(r => r.id !== id));

    // Append to audit logs
    const auditRecord: AuditLog = {
      id: `LOG-${Date.now()}`,
      iconBg: 'bg-rose-600',
      title: `Struk ${item.karyawan} (${item.merchant}) — ditolak Finance Manager`,
      details: `Ditolak oleh Sari Rahma · Nominal ${formatCurrency(item.klaim)} · Alasan: ${note}`,
      waktu: new Date().toLocaleDateString('id-ID')
    };
    setAuditLogs([auditRecord, ...auditLogs]);

    // Add rejection notification
    const notifRecord: NotificationItem = {
      id: `NT-${Date.now()}`,
      type: 'flag',
      title: `Struk ditolak — ${item.karyawan}`,
      subtitle: `Klaim Rp ${new Intl.NumberFormat('id-ID').format(item.klaim)} untuk ${item.merchant} ditolak: ${note || 'Data ditolak'}`,
      time: 'Baru saja',
      read: false
    };
    setNotifications([notifRecord, ...notifications]);
  };

  // 2. Invoice approval/payment handlers
  const handlePayInvoice = (id: string, note: string) => {
    const item = invoices.find(i => i.id === id);
    if (!item) return;

    // Append to invoice history as paid
    const historyRecord: Invoice = {
      ...item,
      status: 'Dibayar',
      catatan: note || 'Pembayaran diselesaikan'
    };

    setInvoiceHistory([historyRecord, ...invoiceHistory]);
    setInvoices(invoices.filter(i => i.id !== id));

    // Append to audit logs
    const auditRecord: AuditLog = {
      id: `LOG-${Date.now()}`,
      iconBg: 'bg-emerald-600',
      title: `${item.id} — berhasil dibayar lunas`,
      details: `Dilunasi oleh Sari Rahma · Vendor: ${item.vendor} · Total nominal: ${formatCurrency(item.total)} · Catatan: ${note}`,
      waktu: new Date().toLocaleDateString('id-ID')
    };
    setAuditLogs([auditRecord, ...auditLogs]);

    // Add success payment notifications
    const notifRecord: NotificationItem = {
      id: `NT-${Date.now()}`,
      type: 'success',
      title: `Pembayaran Lunas — ${item.id}`,
      subtitle: `Transfer Bank Mandiri ke '${item.vendor}' sebesar ${formatCurrency(item.total)} berhasil terproses.`,
      time: 'Baru saja',
      read: false
    };
    setNotifications([notifRecord, ...notifications]);
  };

  const handleApproveInvoice = (id: string, note: string) => {
    const item = invoices.find(i => i.id === id);
    if (!item) return;

    // Append to history as approved (paid as well inside our simple mock logic)
    const historyRecord: Invoice = {
      ...item,
      status: 'Dibayar',
      catatan: note || 'Disetujui untuk pembayaran'
    };

    setInvoiceHistory([historyRecord, ...invoiceHistory]);
    setInvoices(invoices.filter(i => i.id !== id));

    // Append audit
    const auditRecord: AuditLog = {
      id: `LOG-${Date.now()}`,
      iconBg: 'bg-emerald-600',
      title: `${item.id} — disetujui Finance Manager`,
      details: `Disetujui Sari Rahma · Nominal: ${formatCurrency(item.total)} · Vendor: ${item.vendor}`,
      waktu: new Date().toLocaleDateString('id-ID')
    };
    setAuditLogs([auditRecord, ...auditLogs]);

    // Add notification
    const notifRecord: NotificationItem = {
      id: `NT-${Date.now()}`,
      type: 'success',
      title: `Invoice disetujui — ${item.id}`,
      subtitle: `Invoice vendor '${item.vendor}' sebesar ${formatCurrency(item.total)} disetujui Sari Rahma.`,
      time: 'Baru saja',
      read: false
    };
    setNotifications([notifRecord, ...notifications]);
  };

  const handleRejectInvoice = (id: string, note: string) => {
    const item = invoices.find(i => i.id === id);
    if (!item) return;

    // Append details
    const historyRecord: Invoice = {
      ...item,
      status: 'Ditolak',
      catatan: note || 'Ditolak oleh review direksi/finance'
    };

    setInvoiceHistory([historyRecord, ...invoiceHistory]);
    setInvoices(invoices.filter(i => i.id !== id));

    const auditRecord: AuditLog = {
      id: `LOG-${Date.now()}`,
      iconBg: 'bg-rose-600',
      title: `${item.id} — ditolak oleh Finance`,
      details: `Invoice dari ${item.vendor} sebesar ${formatCurrency(item.total)} ditolak: ${note}`,
      waktu: new Date().toLocaleDateString('id-ID')
    };
    setAuditLogs([auditRecord, ...auditLogs]);

    const notifRecord: NotificationItem = {
      id: `NT-${Date.now()}`,
      type: 'flag',
      title: `Invoice Ditolak — ${item.id}`,
      subtitle: `Invoice ${item.vendor} senilai ${formatCurrency(item.total)} ditolak: ${note || 'Alasan ditolak'}`,
      time: 'Baru saja',
      read: false
    };
    setNotifications([notifRecord, ...notifications]);
  };

  // 3. New Invoice creations (Both Scan and Manual inputs)
  const handleAddNewInvoice = (inv: Invoice) => {
    setInvoices([inv, ...invoices]);

    // Append to audit trail
    const auditRecord: AuditLog = {
      id: `LOG-${Date.now()}`,
      iconBg: 'bg-blue-600',
      title: `${inv.id} — disubmit oleh Staff Finance`,
      details: `Diluncurkan oleh Sari Rahma · Sumber: ${inv.sumber} · Nominal total: ${formatCurrency(inv.total)} · Vendor: ${inv.vendor}`,
      waktu: new Date().toLocaleDateString('id-ID')
    };
    setAuditLogs([auditRecord, ...auditLogs]);

    // Add notification
    const notifRecord: NotificationItem = {
      id: `NT-${Date.now()}`,
      type: 'new',
      title: `Invoice Baru Masuk — ${inv.id}`,
      subtitle: `Invoice '${inv.vendor}' senilai ${formatCurrency(inv.total)} menunggu verifikasi.`,
      time: 'Baru saja',
      read: false
    };
    setNotifications([notifRecord, ...notifications]);

    // Send back to inbox
    setActivePage('invoice-inbox');
  };

  // 4. Notifications interaction
  const handleMarkAllRead = () => {
    setNotifications(notifications.map(n => ({ ...n, read: true })));
  };

  const handleDismissNotification = (id: string) => {
    setNotifications(notifications.filter(n => n.id !== id));
  };

  // 5. App Settings interaction
  const handleSaveSettings = (newSettings: AppSettings) => {
    setSettings(newSettings);
    
    // Add audit log for settings update
    const auditRecord: AuditLog = {
      id: `LOG-${Date.now()}`,
      iconBg: 'bg-slate-700',
      title: 'Kebijakan Akuntansi Diperbarui',
      details: `Batas variance diset ke ${newSettings.varianceLimit}% · Batas klaim struk Rp ${new Intl.NumberFormat('id-ID').format(newSettings.maxClaimLimit)}`,
      waktu: new Date().toLocaleDateString('id-ID')
    };
    setAuditLogs([auditRecord, ...auditLogs]);
  };

  const handleAddAuditLogDirect = (title: string, details: string, bgBg: string) => {
    const record: AuditLog = {
      id: `LOG-${Date.now()}`,
      iconBg: bgBg,
      title,
      details,
      waktu: new Date().toLocaleDateString('id-ID')
    };
    setAuditLogs(prev => [record, ...prev]);
  };

  const handleAddNotificationDirect = (type: 'due' | 'flag' | 'new' | 'success', title: string, subtitle: string) => {
    const record: NotificationItem = {
      id: `NT-${Date.now()}`,
      type,
      title,
      subtitle,
      time: 'Baru saja',
      read: false
    };
    setNotifications(prev => [record, ...prev]);
  };

  // Side navigation helper
  const navigateTo = (pageName: string) => {
    setActivePage(pageName);
    setIsSidebarOpen(false); // Close mobile sidebar automatically
  };

  const pageTitles: { [key: string]: string } = {
    'inbox': 'Inbox Struk Karyawan',
    'riwayat-struk': 'Riwayat Approval Struk',
    'invoice-inbox': 'Inbox Invoice Vendor',
    'input-invoice': 'Input Invoice Manual',
    'scan-invoice': 'Scan Invoice OCR',
    'riwayat-invoice': 'Riwayat Approval Invoice',
    'laporan': 'Laporan Gabungan Arus Dana',
    'auditlog': 'Audit Log Transaksi',
    'notif': 'Notifikasi Sistem',
    'setting': 'Pengaturan Dashboard & Threshold',
    'karyawan': 'Manajemen Karyawan',
    'master-vendor': 'Master Data Vendor'
  };

  // Render proper view based on activePage
  const renderContentView = () => {
    switch (activePage) {
      case 'inbox':
        return (
          <ReceiptInbox 
            receipts={receipts} 
            onApprove={handleApproveReceipt} 
            onReject={handleRejectReceipt} 
          />
        );
      case 'riwayat-struk':
        return <ReceiptHistory approvals={receiptHistory} />;
      case 'invoice-inbox':
        return (
          <InvoiceInbox 
            invoices={invoices} 
            onPay={handlePayInvoice} 
            onApprove={handleApproveInvoice} 
            onReject={handleRejectInvoice} 
          />
        );
      case 'input-invoice':
        return <InvoiceInput onAddInvoice={handleAddNewInvoice} />;
      case 'scan-invoice':
        return <InvoiceScan onAddInvoice={handleAddNewInvoice} />;
      case 'riwayat-invoice':
        return <InvoiceHistoryView historyInvoices={invoiceHistory} />;
      case 'laporan':
        return (
          <Reports 
            receipts={receipts} 
            receiptHistory={receiptHistory} 
            invoices={invoices} 
            invoiceHistory={invoiceHistory} 
          />
        );
      case 'auditlog':
        return <AuditLogView logs={auditLogs} />;
      case 'notif':
        return (
          <NotificationsView 
            notifications={notifications} 
            onMarkAllRead={handleMarkAllRead} 
            onDismiss={handleDismissNotification} 
          />
        );
      case 'setting':
        return (
          <SettingsView 
            currentSettings={settings} 
            onSaveSettings={handleSaveSettings} 
          />
        );
      case 'karyawan':
        return (
          <KaryawanManagement 
            onAddAuditLog={handleAddAuditLogDirect} 
            onAddNotification={handleAddNotificationDirect} 
          />
        );
      case 'master-vendor':
        return (
          <MasterVendor 
            onAddAuditLog={handleAddAuditLogDirect} 
            onAddNotification={handleAddNotificationDirect} 
          />
        );
      default:
        return <ReceiptInbox receipts={receipts} onApprove={handleApproveReceipt} onReject={handleRejectReceipt} />;
    }
  };

  const unreadNotifCount = notifications.filter(n => !n.read).length;
  const pendingReceiptCount = receipts.length;
  const pendingInvoiceCount = invoices.length;

  // Audit log audit records generator helper
  const auditReceiptLog = (item: Receipt, approved: boolean, note: string) => {
    return {
      id: `LOG-${Date.now()}`,
      iconBg: approved ? 'bg-emerald-600' : 'bg-rose-600',
      title: `Struk ${item.karyawan} (${item.merchant}) — ${approved ? 'disetujui' : 'ditolak'} Finance Manager`,
      details: `${approved ? 'Disetujui' : 'Ditolak'} Sari Rahma · Nominal: ${formatCurrency(item.klaim)} · Catatan: ${note}`,
      waktu: new Date().toLocaleDateString('id-ID')
    };
  };

  return (
    <div className="min-h-screen bg-slate-50/50 text-slate-805 dark:bg-slate-950 dark:text-slate-100 flex flex-col font-sans antialiased">
      
      {/* Mobile Top Header navbar */}
      <header className="lg:hidden h-14 bg-[#0f172a] text-slate-300 border-b border-slate-800 px-4 flex items-center justify-between sticky top-0 z-40 select-none shadow-sm">
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setIsSidebarOpen(true)}
            className="p-1.5 hover:bg-slate-805 hover:bg-slate-800 rounded-lg text-slate-300 transition"
          >
            <Menu className="w-5 h-5" />
          </button>
          
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 bg-indigo-500 rounded flex items-center justify-center shrink-0">
              <div className="w-3.5 h-3.5 border border-white rounded-xs"></div>
            </div>
            <span className="font-bold text-white text-sm tracking-tight">ExpenseFlow</span>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          {/* Mobile notification shortcut */}
          <button 
            onClick={() => navigateTo('notif')}
            className="relative p-1.5 hover:bg-slate-800 rounded-lg text-slate-300 transition"
          >
            <Bell className="w-4.5 h-4.5" />
            {unreadNotifCount > 0 && (
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-rose-500 animate-ping" />
            )}
          </button>
          
          {/* Mobile Profile logo mockup */}
          <span className="w-7 h-7 rounded-full bg-indigo-500/20 text-indigo-300 font-semibold text-[10px] flex items-center justify-center font-mono">
            SR
          </span>
        </div>
      </header>

      <div className="flex flex-1 relative">
        
        {/* SIDEBAR NAVIGATION PANEL (Responsive overlay on mobile, fixed left panel on desk) */}
        <aside className={`
          fixed inset-y-0 left-0 z-50 lg:z-30 w-64 bg-[#0f172a] text-slate-300 flex flex-col select-none transform transition-transform duration-300 ease-in-out
          lg:translate-x-0 lg:static lg:h-auto
          ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
        `}>
          {/* Sidebar Top branding header */}
          <div className="h-14 lg:h-16 px-5 border-b border-slate-800/60 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-indigo-500 rounded-lg flex items-center justify-center shrink-0 shadow-md shadow-indigo-500/20">
                <div className="w-4 h-4 border-2 border-white rounded-sm"></div>
              </div>
              <div>
                <h1 className="font-bold text-white text-md font-sans tracking-tight leading-none">ExpenseFlow</h1>
                <span className="text-[10px] text-slate-400 block font-medium mt-1">Finance Portal</span>
              </div>
            </div>

            {/* Mobile close sidebar drawer button */}
            <button 
              onClick={() => setIsSidebarOpen(false)}
              className="lg:hidden p-1.5 hover:bg-slate-800 rounded-full text-slate-400 transition"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Sidebar Groups Links scrollbar list */}
          <div className="flex-1 overflow-y-auto px-4 py-5 space-y-6">
            
            {/* Group 1: Employee Receipts */}
            <div className="space-y-1.5">
              <span className="px-3 text-[10px] uppercase tracking-wider text-slate-500 font-bold block mb-2 font-mono">
                Struk Karyawan
              </span>
              
              <button
                onClick={() => navigateTo('inbox')}
                className={`w-full text-left py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors duration-150 ${
                  activePage === 'inbox' 
                    ? 'bg-indigo-600/15 text-white border-l-2 border-indigo-500 pl-2.5' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Inbox className="w-4 h-4 opacity-80" />
                  <span>Inbox Struk</span>
                </div>
                {pendingReceiptCount > 0 && (
                  <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-indigo-500 text-white font-bold font-mono">
                    {pendingReceiptCount}
                  </span>
                )}
              </button>

              <button
                onClick={() => navigateTo('riwayat-struk')}
                className={`w-full text-left py-2 px-3 rounded-lg text-xs font-semibold flex items-center gap-2.5 transition-colors duration-150 ${
                  activePage === 'riwayat-struk' 
                    ? 'bg-indigo-600/15 text-white border-l-2 border-indigo-500 pl-2.5' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <CheckCheck className="w-4 h-4 opacity-80" />
                <span>Riwayat Approval</span>
              </button>
            </div>

            {/* Group 2: Vendor Invoices */}
            <div className="space-y-1.5">
              <span className="px-3 text-[10px] uppercase tracking-wider text-slate-500 font-bold block mb-2 font-mono">
                Invoice Vendor
              </span>
              
              <button
                onClick={() => navigateTo('invoice-inbox')}
                className={`w-full text-left py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors duration-150 ${
                  activePage === 'invoice-inbox' 
                    ? 'bg-indigo-600/15 text-white border-l-2 border-indigo-500 pl-2.5' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <FileText className="w-4 h-4 opacity-80" />
                  <span>Inbox Invoice</span>
                </div>
                {pendingInvoiceCount > 0 && (
                  <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-500 text-white font-bold font-mono">
                    {pendingInvoiceCount}
                  </span>
                )}
              </button>

              <button
                onClick={() => navigateTo('input-invoice')}
                className={`w-full text-left py-2 px-3 rounded-lg text-xs font-semibold flex items-center gap-2.5 transition-colors duration-150 ${
                  activePage === 'input-invoice' 
                    ? 'bg-indigo-600/15 text-white border-l-2 border-indigo-500 pl-2.5' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <FilePlus className="w-4 h-4 opacity-80" />
                <span>Input Invoice</span>
              </button>

              <button
                onClick={() => navigateTo('scan-invoice')}
                className={`w-full text-left py-2 px-3 rounded-lg text-xs font-semibold flex items-center gap-2.5 transition-colors duration-150 ${
                  activePage === 'scan-invoice' 
                    ? 'bg-indigo-600/15 text-white border-l-2 border-indigo-500 pl-2.5' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Scan className="w-4 h-4 opacity-80" />
                <span>Scan Invoice OCR</span>
              </button>

              <button
                onClick={() => navigateTo('riwayat-invoice')}
                className={`w-full text-left py-2 px-3 rounded-lg text-xs font-semibold flex items-center gap-2.5 transition-colors duration-150 ${
                  activePage === 'riwayat-invoice' 
                    ? 'bg-indigo-600/15 text-white border-l-2 border-indigo-500 pl-2.5' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <History className="w-4 h-4 opacity-80" />
                <span>Riwayat Invoice</span>
              </button>

              <button
                onClick={() => navigateTo('master-vendor')}
                className={`w-full text-left py-2 px-3 rounded-lg text-xs font-semibold flex items-center gap-2.5 transition-colors duration-150 ${
                  activePage === 'master-vendor' 
                    ? 'bg-indigo-600/15 text-white border-l-2 border-indigo-500 pl-2.5' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Building className="w-4 h-4 opacity-80" />
                <span>Master Vendor</span>
              </button>
            </div>

            {/* Group 2.5: Manajemen */}
            <div className="space-y-1.5">
              <span className="px-3 text-[10px] uppercase tracking-wider text-slate-500 font-bold block mb-2 font-mono">
                Manajemen
              </span>
              
              <button
                onClick={() => navigateTo('karyawan')}
                className={`w-full text-left py-2 px-3 rounded-lg text-xs font-semibold flex items-center gap-2.5 transition-colors duration-150 ${
                  activePage === 'karyawan' 
                    ? 'bg-indigo-600/15 text-white border-l-2 border-indigo-500 pl-2.5' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Users className="w-4 h-4 opacity-80" />
                <span>Karyawan</span>
              </button>
            </div>

            {/* Group 3: Reporting & Systems */}
            <div className="space-y-1.5">
              <span className="px-3 text-[10px] uppercase tracking-wider text-slate-500 font-bold block mb-2 font-mono">
                Laporan & Sistem
              </span>

              <button
                onClick={() => navigateTo('laporan')}
                className={`w-full text-left py-2 px-3 rounded-lg text-xs font-semibold flex items-center gap-2.5 transition-colors duration-150 ${
                  activePage === 'laporan' 
                    ? 'bg-indigo-600/15 text-white border-l-2 border-indigo-500 pl-2.5' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <BarChart3 className="w-4 h-4 opacity-80" />
                <span>Laporan Gabungan</span>
              </button>

              <button
                onClick={() => navigateTo('auditlog')}
                className={`w-full text-left py-2 px-3 rounded-lg text-xs font-semibold flex items-center gap-2.5 transition-colors duration-150 ${
                  activePage === 'auditlog' 
                    ? 'bg-indigo-600/15 text-white border-l-2 border-indigo-500 pl-2.5' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <ShieldCheck className="w-4 h-4 opacity-80" />
                <span>Audit Log</span>
              </button>

              <button
                onClick={() => navigateTo('notif')}
                className={`w-full text-left py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-between transition-colors duration-150 ${
                  activePage === 'notif' 
                    ? 'bg-indigo-600/15 text-white border-l-2 border-indigo-500 pl-2.5' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Bell className="w-4 h-4 opacity-80" />
                  <span>Notifikasi</span>
                </div>
                {unreadNotifCount > 0 && (
                  <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-rose-500 text-white font-bold font-mono animate-pulse">
                    {unreadNotifCount}
                  </span>
                )}
              </button>
            </div>

            {/* Separator block */}
            <div className="border-t border-slate-800/80 pt-4 space-y-1">
              <button
                onClick={() => navigateTo('setting')}
                className={`w-full text-left py-2 px-3 rounded-lg text-xs font-semibold flex items-center gap-2.5 transition-colors duration-150 ${
                  activePage === 'setting' 
                    ? 'bg-indigo-600/15 text-white border-l-2 border-indigo-500 pl-2.5' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Settings className="w-4 h-4 opacity-80" />
                <span>Pengaturan Aturan</span>
              </button>
            </div>

          </div>

          {/* Fixed bottom footer with avatar */}
          <div className="p-4 border-t border-slate-800 shrink-0">
            <div className="flex items-center gap-3 bg-slate-900/60 p-2.5 rounded-xl border border-slate-850">
              <span className="w-8 h-8 rounded-full bg-indigo-550 bg-indigo-600/20 border border-indigo-500/30 text-indigo-300 font-bold text-xs flex items-center justify-center shrink-0 font-mono">
                SR
              </span>
              <div className="min-w-0">
                <p className="text-[11px] font-bold text-white truncate">Sari Rahma</p>
                <p className="text-[10px] text-slate-400 truncate">Finance Manager</p>
              </div>
            </div>
          </div>
        </aside>

        {/* Mobile sidebar overlay backdrop */}
        {isSidebarOpen && (
          <div 
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-40 lg:hidden"
          />
        )}

        {/* MAIN BODY LAYOUT WRAPPER */}
        <main className="flex-1 flex flex-col min-w-0">
          
          {/* Main Top Header Navbar (Desktop Only) */}
          <header className="hidden lg:flex h-16 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-8 items-center justify-between sticky top-0 z-20 select-none">
            <div className="flex items-center gap-3">
              <h2 className="font-bold text-slate-800 dark:text-white text-sm tracking-tight font-sans uppercase">System Portal</h2>
              <span className="text-slate-300">/</span>
              <span className="text-xs font-semibold text-slate-500 font-sans">
                {pageTitles[activePage] || 'Portal'}
              </span>
            </div>

            <div className="flex items-center gap-4">
              {/* Shortcut buttons */}
              <button 
                onClick={() => alert('Exporting global ledger reports...')}
                className="flex items-center gap-1.5 px-3 py-1.5 border border-slate-200 dark:border-slate-750 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg text-xs font-semibold text-slate-600 dark:text-slate-350 transition"
              >
                <Download className="w-3.5 h-3.5 text-indigo-550 text-indigo-500" />
                <span>Export Gabungan</span>
              </button>

              <div className="flex items-center gap-2.5">
                <span className="w-8 h-8 rounded-full bg-indigo-50 text-indigo-600 font-bold text-xs flex items-center justify-center font-mono shrink-0 border border-indigo-100">SR</span>
                <div className="text-left leading-none">
                  <span className="text-[11px] font-bold text-slate-800 dark:text-white block">Sari Rahma</span>
                  <span className="text-[9px] text-slate-400 block mt-1">Level II Approver</span>
                </div>
              </div>
            </div>
          </header>

          {/* SCROLLABLE INTERACTIVE VIEW CONTENT CONTAINER */}
          <div className="flex-1 p-6 md:p-8 overflow-y-auto space-y-6">
            
            {/* Real responsive Header Title block on Desktop/Mobile */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div>
                <h2 className="text-lg md:text-xl font-bold text-slate-900 dark:text-white tracking-tight leading-none font-sans flex items-center gap-2">
                  {activePage === 'inbox' && <ReceiptIcon className="w-5 h-5 text-indigo-500 shrink-0" />}
                  {pageTitles[activePage] || 'ExpenseFlow Portal'}
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5 font-sans">
                  Sistem verifikasi otomatis multi-channel berbasis OCR &amp; fraud alert flag
                </p>
              </div>
            </div>

            {/* Render selected controller view on-the-fly */}
            <div className="animate-in fade-in slide-in-from-bottom-2 duration-355 duration-300">
              {renderContentView()}
            </div>

          </div>

        </main>

      </div>
    </div>
  );
}
